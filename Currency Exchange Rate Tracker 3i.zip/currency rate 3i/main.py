# main.py

import streamlit as st  # Web framework
from config import SUPPORTED_CURRENCIES
from components.exchange_api import fetch_exchange_rates
from components.converter import convert_currency
from components.visuals import plot_exchange_trends
from components.multi_converter import multi_currency_conversion
from components.predictor import predict_future_rates

# Set page settings
st.set_page_config(page_title="Currency Exchange Tracker", page_icon="💱", layout="centered")

# App Title
st.title("\U0001F4B1 Currency Exchange Rate Tracker")

# Sidebar navigation
menu = st.sidebar.radio("Select Feature", [
    "📈 Live Rates Overview",
    "💵 Currency Converter",
    "📊 Exchange Rate Trends",
    "💸 Multi-Currency Converter",
    "🔬 Predict Future Rates"
])

# Load exchange rates for base currency (default USD)
base_currency = st.sidebar.selectbox("Base Currency", SUPPORTED_CURRENCIES)
rates = fetch_exchange_rates(base_currency)

# Handle menu logic
if not rates:
    st.error("Could not fetch exchange rates. Please check your internet connection or API key.")

elif menu == "📈 Live Rates Overview":
    st.subheader("📈 Current Exchange Rates")
    st.write(f"Base currency: **{base_currency}**")
    st.table({cur: round(rate, 4) for cur, rate in rates.items() if cur in SUPPORTED_CURRENCIES})

elif menu == "💵 Currency Converter":
    st.subheader("💵 Convert Currency")
    from_currency = st.selectbox("From", SUPPORTED_CURRENCIES)
    to_currency = st.selectbox("To", SUPPORTED_CURRENCIES)
    amount = st.number_input("Amount", min_value=0.0, value=100.0)
    if st.button("Convert"):
        result = convert_currency(amount, from_currency, to_currency, rates)
        st.success(f"{amount} {from_currency} = {result} {to_currency}")

elif menu == "📊 Exchange Rate Trends":
    st.subheader("📊 Exchange Rate Trends")
    fig = plot_exchange_trends(base_currency, rates, SUPPORTED_CURRENCIES)
    st.plotly_chart(fig, use_container_width=True)

elif menu == "💸 Multi-Currency Converter":
    st.subheader("💸 Convert {base_currency} to Multiple Currencies")
    amount = st.number_input("Amount in Base Currency", min_value=0.0, value=100.0)
    multi_results = multi_currency_conversion(amount, base_currency, SUPPORTED_CURRENCIES, rates)
    st.table(multi_results)

elif menu == "🔬 Predict Future Rates":
    st.subheader("🔬 Predict Future Exchange Rate")
    target_currency = st.selectbox("Select currency to predict", [c for c in SUPPORTED_CURRENCIES if c != base_currency])
    fig = predict_future_rates(base_currency, target_currency)
    if fig:
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.warning("Prediction unavailable due to data limitations.")

# Footer
st.markdown("---")
st.caption("Powered by exchangeratesapi.io | Built by Yusuf, Doris, Aisha and Peter ")

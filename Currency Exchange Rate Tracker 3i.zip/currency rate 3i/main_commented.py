# main.py

# Importing Streamlit, which is a Python tool that lets you build interactive web apps easily
import streamlit as st

# Importing a list of currency codes we support (like USD, EUR, GBP, etc.)
from config import SUPPORTED_CURRENCIES

# Importing functions from other files (modules) that help us perform tasks
from components.exchange_api import fetch_exchange_rates  # Connects to the internet and gets the latest exchange rates
from components.converter import convert_currency         # Converts one currency amount into another
from components.visuals import plot_exchange_trends       # Draws a graph to show how currency rates have changed
from components.multi_converter import multi_currency_conversion  # Converts an amount into several currencies at once
from components.predictor import predict_future_rates     # Guesses (predicts) what the future rate might be

# Setting the basic settings of the web page (title on the tab, icon, and layout style)
st.set_page_config(page_title="Currency Exchange Tracker", page_icon="💱", layout="centered")

# Display the title of the app at the top of the screen
st.title("💱 Currency Exchange Rate Tracker")

# This creates a sidebar (on the left) where the user can pick what feature they want to use
menu = st.sidebar.radio("Select Feature", [
    "📈 Live Rates Overview",         # Option 1: See current rates
    "💵 Currency Converter",          # Option 2: Convert one currency to another
    "📊 Exchange Rate Trends",        # Option 3: Show currency history on a chart
    "💸 Multi-Currency Converter",    # Option 4: Convert one amount into many currencies
    "🔬 Predict Future Rates"         # Option 5: Forecast future exchange rates
])

# Here, the user picks their base currency (like "I want to convert from USD")
base_currency = st.sidebar.selectbox("Base Currency", SUPPORTED_CURRENCIES)

# This line fetches the latest exchange rates for the selected base currency from the API
rates = fetch_exchange_rates(base_currency)

# If the rates couldn't be loaded (maybe no internet or wrong key), show an error message
if not rates:
    st.error("Could not fetch exchange rates. Please check your internet connection or API key.")

# If the user picked the first option - show the live rates
elif menu == "📈 Live Rates Overview":
    st.subheader("📈 Current Exchange Rates")  # Sub-heading
    st.write(f"Base currency: **{base_currency}**")  # Show which base currency is used
    # Display the rates for supported currencies in a table (rounded to 4 decimal places)
    st.table({cur: round(rate, 4) for cur, rate in rates.items() if cur in SUPPORTED_CURRENCIES})

# If the user picked the currency converter
elif menu == "💵 Currency Converter":
    st.subheader("💵 Convert Currency")  # Sub-heading
    from_currency = st.selectbox("From", SUPPORTED_CURRENCIES)  # Pick the currency to convert from
    to_currency = st.selectbox("To", SUPPORTED_CURRENCIES)      # Pick the currency to convert to
    amount = st.number_input("Amount", min_value=0.0, value=100.0)  # Enter amount to convert

    # When the user clicks the button, do the conversion
    if st.button("Convert"):
        result = convert_currency(amount, from_currency, to_currency, rates)  # Convert
        st.success(f"{amount} {from_currency} = {result} {to_currency}")      # Show result

# If the user picked the trend chart
elif menu == "📊 Exchange Rate Trends":
    st.subheader("📊 Exchange Rate Trends")  # Sub-heading
    # Call the function to create a graph based on historical or static data
    fig = plot_exchange_trends(base_currency, rates, SUPPORTED_CURRENCIES)
    # Display the graph
    st.plotly_chart(fig, use_container_width=True)

# If the user picked multi-currency converter
elif menu == "💸 Multi-Currency Converter":
    st.subheader(f"💸 Convert {base_currency} to Multiple Currencies")  # Sub-heading with base currency
    amount = st.number_input("Amount in Base Currency", min_value=0.0, value=100.0)  # User inputs amount
    # Convert to all supported currencies at once
    multi_results = multi_currency_conversion(amount, base_currency, SUPPORTED_CURRENCIES, rates)
    # Show the result as a table
    st.table(multi_results)

# If the user picked to predict future rates
elif menu == "🔬 Predict Future Rates":
    st.subheader("🔬 Predict Future Exchange Rate")  # Sub-heading
    # Let the user pick which currency they want to forecast (excluding base currency)
    target_currency = st.selectbox("Select currency to predict", [c for c in SUPPORTED_CURRENCIES if c != base_currency])
    # Call the function to get a chart prediction
    fig = predict_future_rates(base_currency, target_currency)

    # If a chart was returned, show it
    if fig:
        st.plotly_chart(fig, use_container_width=True)
    else:
        # Otherwise tell the user prediction is not available
        st.warning("Prediction unavailable due to data limitations.")

# Footer line
st.markdown("---")
# Small text at the bottom saying who built the app
st.caption("Powered by exchangeratesapi.io | Built by Yusuf, Doris, Aisha and Peter")

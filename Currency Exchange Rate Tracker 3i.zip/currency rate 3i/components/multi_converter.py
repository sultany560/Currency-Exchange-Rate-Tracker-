# components/multi_converter.py

# Import function to convert currency
from .converter import convert_currency

# Multi-currency conversion logic
def multi_currency_conversion(amount, base_currency, target_currencies, rates):
    """
    Convert a base currency amount to multiple target currencies using current rates.

    Parameters:
        amount (float): Amount in base currency
        base_currency (str): Currency to convert from
        target_currencies (list): List of currencies to convert to
        rates (dict): Dictionary of currency rates relative to base_currency

    Returns:
        dict: Mapping of each target currency to its converted amount
    """
    # Initialize result dictionary
    result = {}

    # Loop through target currencies
    for target in target_currencies:
        # Avoid converting to the same currency
        if target != base_currency:
            # Convert amount and round the result
            result[target] = round(convert_currency(amount, base_currency, target, rates), 4)

    return result

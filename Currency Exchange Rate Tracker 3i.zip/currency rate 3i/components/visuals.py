# visuals.py

# Import necessary libraries for data processing and plotting
import pandas as pd
import plotly.express as px

# Import conversion function to standardize all values for chart
from components.converter import convert_currency


def plot_exchange_trends(base_currency, rates, currency_list):
    """
    Generate a Plotly bar chart showing exchange rates relative to the base currency.

    Parameters:
        base_currency (str): The selected base currency
        rates (dict): Dictionary of exchange rates
        currency_list (list): List of currencies to include in the graph

    Returns:
        Plotly figure object: A bar chart displaying exchange rates
    """
    # Convert 1 unit of base currency to other currencies for trend visualization
    data = {
        currency: convert_currency(1, base_currency, currency, rates)
        for currency in currency_list
    }

    # Create a DataFrame from the dictionary for plotting
    df = pd.DataFrame(list(data.items()), columns=["Currency", "Rate"])

    # Generate a Plotly bar chart using the DataFrame
    fig = px.bar(
        df,
        x="Currency",
        y="Rate",
        text="Rate",
        title=f"Exchange Rates vs {base_currency}",
        color="Rate",
        color_continuous_scale="Blues"
    )

    # Return the plot
    return fig

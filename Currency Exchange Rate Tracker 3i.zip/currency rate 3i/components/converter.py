# converter.py

def convert_currency(amount, from_currency, to_currency, rates):
    """
    Convert an amount from one currency to another using real-time exchange rates.

    Parameters:
        amount (float): The amount of money to convert
        from_currency (str): The currency to convert from
        to_currency (str): The currency to convert to
        rates (dict): A dictionary of exchange rates

    Returns:
        float: The converted amount rounded to 2 decimal places
    """
    # If both currencies are the same, return the original amount
    if from_currency == to_currency:
        return amount

    # Perform the conversion using the rates dictionary
    converted = amount * rates[to_currency] / rates[from_currency]

    # Return the result rounded to 2 decimal places
    return round(converted, 2)

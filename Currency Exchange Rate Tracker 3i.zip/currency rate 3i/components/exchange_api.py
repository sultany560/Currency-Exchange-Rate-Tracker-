# exchange_api.py

# Importing requests to handle HTTP requests
import requests

# Import API configuration values from config.py
from config import API_KEY, BASE_URL


def fetch_exchange_rates(base_currency):
    """
    Fetch real-time exchange rates from the API based on the base currency.

    Parameters:
        base_currency (str): The currency to base the exchange rates on (e.g. USD)

    Returns:
        dict: A dictionary of exchange rates with currency codes as keys
    """
    # Compose the API endpoint with access key and base currency
    url = f"{BASE_URL}?access_key={API_KEY}&base={base_currency}"

    # Send a GET request to the API
    response = requests.get(url)

    # Parse the JSON response
    data = response.json()

    # Return the rates if available, otherwise return an empty dictionary
    return data.get("rates", {})

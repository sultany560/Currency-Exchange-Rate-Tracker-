# components/predictor.py

import pandas as pd
import numpy as np
import plotly.graph_objects as go
from sklearn.linear_model import LinearRegression
import datetime
import yfinance as yf


def predict_future_rates(base_currency, target_currency):
    """
    Predict future exchange rates using historical data and linear regression.

    Parameters:
        base_currency (str): Currency to convert from (e.g., 'USD')
        target_currency (str): Currency to convert to (e.g., 'EUR')

    Returns:
        plotly.graph_objs.Figure: Prediction chart
    """
    try:
        # Define the currency pair symbol (Yahoo Finance format)
        pair = f"{base_currency}{target_currency}=X"

        # Download historical data for the past 60 days
        df = yf.download(pair, period="60d", interval="1d")

        # If no data found, return None
        if df.empty:
            return None

        # Prepare the data for regression
        df = df.reset_index()
        df['Days'] = np.arange(len(df))
        X = df[['Days']]
        y = df['Close']

        # Fit linear regression
        model = LinearRegression()
        model.fit(X, y)

        # Predict for next 15 days
        future_days = np.arange(len(df), len(df) + 15)
        predictions = model.predict(future_days.reshape(-1, 1))

        # Create prediction DataFrame
        future_dates = [df['Date'].iloc[-1] + datetime.timedelta(days=i) for i in range(1, 16)]
        pred_df = pd.DataFrame({"Date": future_dates, "Predicted": predictions})

        # Plot actual and predicted prices
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=df['Date'], y=y, mode='lines+markers', name='Historical'))
        fig.add_trace(go.Scatter(x=pred_df['Date'], y=pred_df['Predicted'], mode='lines+markers', name='Predicted'))
        fig.update_layout(title=f"{base_currency} to {target_currency} - 15 Day Forecast",
                          xaxis_title="Date", yaxis_title="Exchange Rate")

        return fig

    except Exception as e:
        print("Prediction Error:", e)
        return None

# config.py

# List of supported currencies in the tracker
SUPPORTED_CURRENCIES = ["USD", "EUR", "GBP", "JPY", "NGN"]

# Your API key for accessing the exchange rates API
API_KEY = "d27f2f1d90ebe390cb2a12cc07f8013f"

# Base URL for the exchange rate API
BASE_URL = "https://api.exchangeratesapi.io/latest"
